import List from "../assets/images/list.svg";
import Hyyat from "../assets/images/hotel/hyyat.png";
import Hilton4 from "../assets/images/hotel/hilton(4).png";
import Hilton5 from "../assets/images/hotel/hilton(5s).png";
import Ihthotel from "../assets/images/hotel/ihthotel.png";
import Lumiere from "../assets/images/hotel/Lumiere.png";
import Marriot from "../assets/images/hotel/Marriot.png";
import Pragahotel from "../assets/images/hotel/Pragahotel.png";
import Hotel101 from "../assets/images/hotel/101Hotel.png";
import Soil from "../assets/images/logo/Soil.png";
import Agrouz from "../assets/images/logo/Agrouz.png";
import Akis from "../assets/images/logo/Akis.png";
import Food from "../assets/images/logo/Food.png";
import Tdau from "../assets/images/logo/Tdau.png";
import Ifoda from "../assets/images/logo/Ifoda.png";
import Nuu from "../assets/images/logo/Nuu.png";
import Tokyo from "../assets/images/logo/Tokyo.png";
import Zagreb from "../assets/images/logo/Zagreb.png";

export const images = {
  List,
  Hyyat,
  Hilton4,
  Hilton5,
  Ihthotel,
  Lumiere,
  Marriot,
  Pragahotel,
  Hotel101,
  Soil,
  Agrouz,
  Akis,
  Food,
  Tdau,
  Ifoda,
  Nuu,
  Tokyo,
  Zagreb,
};
