import List from "../assets/images/list.svg";
import Hyyat from "../assets/images/hotel/hyyat.png";
import Hilton4 from "../assets/images/hotel/hilton(4).png";
import Hilton5 from "../assets/images/hotel/hilton(5s).png";
import Ihthotel from "../assets/images/hotel/ihthotel.png";
import Lumiere from "../assets/images/hotel/Lumiere.png";
import Marriot from "../assets/images/hotel/Marriot.png";
import Pragahotel from "../assets/images/hotel/Pragahotel.png";
import Hotel101 from "../assets/images/hotel/101Hotel.png";
import Soil from "../Yahyobek-img/img-1.png";
import Agrouz from "../Yahyobek-img/img-2.png";
import Akis from "../Yahyobek-img/img-3.png";
import Food from "../Yahyobek-img/img-4.png";
import Tdau from "../Yahyobek-img/img-5.png";
import Ifoda from "../Yahyobek-img/img-6.png";
import Nuu from "../Yahyobek-img/img-7.png";
import Tokyo from "../Yahyobek-img/img-8.png";
import Zagreb from "../Yahyobek-img/img-9.png";
import Icarda from "../Yahyobek-img/img-10.png";
import Minstry  from "../Yahyobek-img/img-11.png";
// import Soil from "../Yahyobek-img/"


export const images = {
  List,
  Hyyat,
  Hilton4,
  Hilton5,
  Ihthotel,
  Lumiere,
  Marriot,
  Pragahotel,
  Hotel101,
  Soil,
  Agrouz,
  Akis,
  Food,
  Tdau,
  Ifoda,
  Nuu,
  Tokyo,
  Zagreb,
  Icarda,
  Minstry,
};
