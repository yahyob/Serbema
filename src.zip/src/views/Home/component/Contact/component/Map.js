import React from "react";


function YandexMap() {
  return (
    <>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2997.6486414220926!2d69.2254687!3d41.2947508!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38ae8b62ad6c0735%3A0x2260c74fb009b861!2z0I7Qt9Cx0LXQutC40YHRgtC-0L0g0KDQtdGB0L_Rg9Cx0LvQuNC60LDRgdC4INCt0LrQvtC70L7Qs9C40Y8g0LLQsCDQsNGC0YDQvtGEINC80YPSs9C40YLQvdC4INC80YPSs9C-0YTQsNC30LAg0pvQuNC70LjRiCDQtNCw0LLQu9Cw0YIg0pvRntC80LjRgtCw0YHQuA!5e0!3m2!1sen!2s!4v1676961851094!5m2!1sen!2s" width="100%" height="300" style={{ border: "0" }} allowfullscreen="true" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>      {/* <YMaps>
      <Map
        width={"100%"}
        height={300}
        defaultState={{
          center: [41.27320368314806, 69.20369159621069],
          zoom: 13,
        }}
      >
        <Placemark geometry={[41.28323535583633, 69.20856011314021]} />
      </Map>
    </YMaps> */}
    </>
  );
}

export default YandexMap;
